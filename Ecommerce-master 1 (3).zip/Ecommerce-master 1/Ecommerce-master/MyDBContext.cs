﻿using Microsoft.EntityFrameworkCore;
using E_commerce.Model;

namespace E_commerce
{
    internal class MyDBContext : DbContext
    {
        public DbSet<Product> Product { get; set; }
        public DbSet<Categorie> Categorie { get; set; }
        public DbSet<Klant> Klant { get; set; }
        public DbSet<Bestelling> Bestelling { get; set; }
        public DbSet<BestelRegel> BestelRegels { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=localhost\SQLEXPRESS;Database=e-commerce;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=true");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Bestelling>()
                .HasOne(b => b.Product)
                .WithMany()
                .HasForeignKey(b => b.ProductIdd); // Dit moet overeenkomen met de eigenschap in de Bestelling-klasse
        }

    }
}
