﻿using E_commerce.Model;
using System;

internal class Bestelling
{
    public int Id { get; set; }
    public DateTime Datum { get; set; }
    public int KlantId { get; set; }
    public int ProductIdd { get; set; } // Nieuw toegevoegde kolom voor ProductId

    public Product Product { get; set; }
    // Andere eigenschappen en methoden...
}
