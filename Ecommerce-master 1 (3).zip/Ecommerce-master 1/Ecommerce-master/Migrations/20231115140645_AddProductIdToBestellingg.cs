﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace E_commerce.Migrations
{
    /// <inheritdoc />
    public partial class AddProductIdToBestellingg : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Bestelling_Product_ProductId",
                table: "Bestelling");

            migrationBuilder.RenameColumn(
                name: "ProductId",
                table: "Bestelling",
                newName: "ProductIdd");

            migrationBuilder.RenameIndex(
                name: "IX_Bestelling_ProductId",
                table: "Bestelling",
                newName: "IX_Bestelling_ProductIdd");

            migrationBuilder.AddForeignKey(
                name: "FK_Bestelling_Product_ProductIdd",
                table: "Bestelling",
                column: "ProductIdd",
                principalTable: "Product",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Bestelling_Product_ProductIdd",
                table: "Bestelling");

            migrationBuilder.RenameColumn(
                name: "ProductIdd",
                table: "Bestelling",
                newName: "ProductId");

            migrationBuilder.RenameIndex(
                name: "IX_Bestelling_ProductIdd",
                table: "Bestelling",
                newName: "IX_Bestelling_ProductId");

            migrationBuilder.AddForeignKey(
                name: "FK_Bestelling_Product_ProductId",
                table: "Bestelling",
                column: "ProductId",
                principalTable: "Product",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
