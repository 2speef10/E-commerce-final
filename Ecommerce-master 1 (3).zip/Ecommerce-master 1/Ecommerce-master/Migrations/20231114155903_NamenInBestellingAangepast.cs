﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace E_commerce.Migrations
{
    /// <inheritdoc />
    public partial class NamenInBestellingAangepast : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Bestellings_Product_ProductId",
                table: "Bestellings");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Bestellings",
                table: "Bestellings");

            migrationBuilder.RenameTable(
                name: "Bestellings",
                newName: "Bestelling");

            migrationBuilder.RenameIndex(
                name: "IX_Bestellings_ProductId",
                table: "Bestelling",
                newName: "IX_Bestelling_ProductId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Bestelling",
                table: "Bestelling",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Bestelling_Product_ProductId",
                table: "Bestelling",
                column: "ProductId",
                principalTable: "Product",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Bestelling_Product_ProductId",
                table: "Bestelling");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Bestelling",
                table: "Bestelling");

            migrationBuilder.RenameTable(
                name: "Bestelling",
                newName: "Bestellings");

            migrationBuilder.RenameIndex(
                name: "IX_Bestelling_ProductId",
                table: "Bestellings",
                newName: "IX_Bestellings_ProductId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Bestellings",
                table: "Bestellings",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Bestellings_Product_ProductId",
                table: "Bestellings",
                column: "ProductId",
                principalTable: "Product",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
